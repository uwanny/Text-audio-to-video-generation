# Training Wrapper

Utility code to run training and evaluation of the model.
